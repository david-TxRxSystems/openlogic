# TaskBridge + ProtonMail Deployment

## How to Use

1. Make sure you have already logged in via:

```bash
docker run --rm -it -v protonmail-bridge-data:/root shenxn/protonmail-bridge protonmail-bridge --cli
```

2. Extract this tarball and run:

```bash
docker-compose up -d --build
```

3. Check logs:

```bash
docker logs -f taskbridge
```

You should see messages being synced from ProtonMail and added to Google Calendar.
